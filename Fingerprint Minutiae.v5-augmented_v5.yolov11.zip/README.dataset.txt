# Fingerprint Minutiae > Augmented_v5
https://universe.roboflow.com/khubab-ahmad/fingerprint-minutiae

Provided by a Roboflow user
License: CC BY 4.0

